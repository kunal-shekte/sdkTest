package airpush

import com.facebook.react.ReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.uimanager.ViewManager

class AppsAirPushPackage : ReactPackage {

    override fun createNativeModules(reactContext: ReactApplicationContext): List<NativeModule> {
        return listOf(AppsAirPushModule(reactContext))
    }

    override fun createViewManagers(reactContext: ReactApplicationContext)
      : List<ViewManager<*, *>> = emptyList()
}
