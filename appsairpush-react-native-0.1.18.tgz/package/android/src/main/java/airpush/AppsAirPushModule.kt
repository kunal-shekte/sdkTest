package airpush

import android.content.Context
import android.os.Build
import com.facebook.react.bridge.*
import java.io.*
import java.net.URLEncoder
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

class AppsAirPushModule(reactContext: ReactApplicationContext)
  : ReactContextBaseJavaModule(reactContext) {

    override fun getName(): String = "AppsAirPush"

    companion object {
        private const val CRASH_THRESHOLD = 2
        private const val PREFS_NAME = "appsairpush_meta"
        private const val KEY_CRASH_COUNTER = "crash_counter"
        private const val KEY_BINARY_VERSION = "binary_version_key"
        private const val KEY_LAST_LAUNCH_TS = "last_launch_ts"
        private const val BASE_URL = "https://boldly-achlamydeous-sharonda.ngrok-free.dev"

        private fun reportCrashToServer(context: Context, crashCount: Int, timeSinceLastLaunchMs: Long) {
            try {
                val versionFile = File(context.filesDir, "version_name.txt")
                val appIdFile = File(context.filesDir, "app_id.txt")
                if (!versionFile.exists() || !appIdFile.exists()) return

                val versionName = versionFile.readText().trim()
                val appId = appIdFile.readText().trim()
                if (versionName.isEmpty() || appId.isEmpty()) return

                val nativeVersion = context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "0.0.0"

                // Determine crash reason based on timing
                val reason = if (timeSinceLastLaunchMs in 0..10000) "restart_too_fast" else "js_boot_failure"

                // Check if app is running in debug mode
                val isDebug = try {
                    (context.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
                } catch (_: Exception) { false }

                val deviceModel = URLEncoder.encode("${Build.MANUFACTURER} ${Build.MODEL}", "UTF-8")
                val osVersion = URLEncoder.encode("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})", "UTF-8")

                Thread {
                    try {
                        val url = java.net.URL(
                            "$BASE_URL/api/v1/bundle/reportCrash" +
                            "?platform=android&appId=$appId&versionName=$versionName&nativeVersion=$nativeVersion" +
                            "&reason=$reason&crashCount=$crashCount&timeSinceLastLaunchMs=$timeSinceLastLaunchMs" +
                            "&isDebug=$isDebug&deviceModel=$deviceModel&osVersion=$osVersion"
                        )
                        val conn = url.openConnection() as java.net.HttpURLConnection
                        conn.requestMethod = "GET"
                        conn.connectTimeout = 5000
                        conn.readTimeout = 5000
                        conn.responseCode
                        conn.disconnect()
                    } catch (_: Exception) {}
                }.start()
            } catch (_: Exception) {}
        }

        fun getJSBundleFile(context: Context): String {
            return try {
                val prefs =
                    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

                val currentBinaryKey = context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: ""
                val lastBinaryKey = prefs.getString(KEY_BINARY_VERSION, "")

                val otaDir = File(context.filesDir, "ota")
                val otaBundle = File(otaDir, "main.jsbundle")
                val versionFile = File(context.filesDir, "version_name.txt")

                // Binary version changed (versionName) — wipe OTA, reset counter
                if (lastBinaryKey != currentBinaryKey) {
                    if (otaDir.exists()) {
                        otaDir.deleteRecursively()
                    }
                    if (versionFile.exists()) {
                        versionFile.delete()
                    }
                    val blacklistFile = File(context.filesDir, "blacklisted_versions.txt")
                    if (blacklistFile.exists()) {
                        blacklistFile.delete()
                    }
                    prefs.edit()
                        .putString(KEY_BINARY_VERSION, currentBinaryKey)
                        .putInt(KEY_CRASH_COUNTER, 0)
                        .apply()

                    return "assets://index.android.bundle"
                }

                // --- Crash-safe boot guard ---
                // Save launch timestamp for crash diagnostics
                val now = System.currentTimeMillis()
                val lastLaunchTs = prefs.getLong(KEY_LAST_LAUNCH_TS, 0L)
                val timeSinceLastLaunchMs = if (lastLaunchTs > 0) now - lastLaunchTs else -1L
                prefs.edit().putLong(KEY_LAST_LAUNCH_TS, now).apply()

                // Increment crash counter BEFORE JS loads.
                // If JS boots successfully, init() will call crashCounterReset() to reset it.
                val crashCount = prefs.getInt(KEY_CRASH_COUNTER, 0) + 1
                prefs.edit().putInt(KEY_CRASH_COUNTER, crashCount).commit()

                if (crashCount >= CRASH_THRESHOLD && otaDir.exists()) {
                    // Report crash to server with diagnostic info
                    reportCrashToServer(context, crashCount, timeSinceLastLaunchMs)
                    
                    if (versionFile.exists()) {
                        try {
                            val crashingVersion = versionFile.readText().trim()
                            if (crashingVersion.isNotEmpty()) {
                                val blacklistFile = File(context.filesDir, "blacklisted_versions.txt")
                                blacklistFile.appendText("$crashingVersion,")
                            }
                        } catch (_: Exception) {}
                        versionFile.delete()
                    }
                    
                    // Also wipe the OTA-install flag so the JS layer does NOT skip
                    // the update check on this recovery launch. Without this, the
                    // flag causes skipCheck=true and the latest bundle is only
                    // fetched on the *next* launch instead of immediately.
                    val flagFile = File(context.filesDir, "ota_installed.txt")
                    if (flagFile.exists()) flagFile.delete()

                    otaDir.deleteRecursively()
                    prefs.edit().putInt(KEY_CRASH_COUNTER, 0).commit()
                    return "assets://index.android.bundle"
                }

                if (otaBundle.exists()) {
                    otaBundle.absolutePath
                } else {
                    // No OTA on disk — reset counter, nothing to guard against
                    prefs.edit().putInt(KEY_CRASH_COUNTER, 0).apply()
                    "assets://index.android.bundle"
                }
            } catch (e: Exception) {
                "assets://index.android.bundle"
            }
        }
    }

    // ---------------------------
    // Crash guard: reset counter
    // ---------------------------
    @ReactMethod
    fun crashCounterReset(promise: Promise) {
        try {
            val prefs = reactApplicationContext
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putInt(KEY_CRASH_COUNTER, 0).apply()
            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("CRASH_GUARD_ERROR", e.message)
        }
    }

    // ---------------------------
    // Native unzip for OTA
    // ---------------------------
    @ReactMethod
    fun unzip(zipPath: String, destPath: String, promise: Promise) {
        try {
            val buffer = ByteArray(1024)
            val folder = File(destPath)
            if (!folder.exists()) folder.mkdirs()

            val zipInput = ZipInputStream(FileInputStream(zipPath))
            var entry: ZipEntry? = zipInput.nextEntry

            while (entry != null) {
                val file = File(destPath, entry.name)

                if (entry.isDirectory) {
                    file.mkdirs()
                } else {
                    file.parentFile?.mkdirs()
                    val output = FileOutputStream(file)

                    var len: Int
                    while (zipInput.read(buffer).also { len = it } > 0) {
                        output.write(buffer, 0, len)
                    }

                    output.close()
                }

                zipInput.closeEntry()
                entry = zipInput.nextEntry
            }

            zipInput.close()
            promise.resolve(true)

        } catch (e: Exception) {
            promise.reject("unzip_error", e.localizedMessage)
        }
    }

   @ReactMethod
    fun getNativeAppVersion(promise: Promise) {
        try {
            val context = reactApplicationContext
            val pInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            promise.resolve(pInfo.versionName)
        } catch (e: Exception) {
            promise.reject("VERSION_ERROR", e.message)
        }
    }

}
