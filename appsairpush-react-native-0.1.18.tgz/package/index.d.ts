declare module "appsairpush-react-native" {
  interface AppsAirPushConfig {
    appId: string
  }

  interface UpdateCheckResult {
    hasUpdate: boolean;
    version_name?: string;
    url?: string;
    error?: boolean;
    message?: string;
  }

  interface InstallResult {
    success: boolean;
    error?: string;
  }

  interface SyncResult {
    updated: boolean;
    error?: string;
  }

  interface DownloadEvent {
    bytesWritten: number;
    contentLength: number;
    /** 0 to 100 */
    progress: number;
  }

  type OnDownload = (download: DownloadEvent) => void;

  const AppsAirPush: {
    init(config: AppsAirPushConfig): void;
    checkForUpdate(): Promise<UpdateCheckResult>;
    downloadAndInstall(
      data: { version_name: string; url: string },
      onDownload?: OnDownload
    ): Promise<InstallResult>;

    sync(
      config: AppsAirPushConfig,
      onDownload?: OnDownload
    ): Promise<SyncResult>;
  };

  export default AppsAirPush;
}
