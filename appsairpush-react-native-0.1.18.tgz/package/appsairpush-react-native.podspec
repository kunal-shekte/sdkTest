Pod::Spec.new do |s|
  s.name          = "appsairpush-react-native"
  s.version       = "0.0.1"
  s.summary       = "AppsAirPush OTA"
  s.homepage      = "https://example.com"
  s.authors       = { "AppsAirPush" => "support@example.com" }

  s.license       = { :type => "MIT", :file => "LICENSE" }

  s.platform      = :ios, "11.0"

  # Dummy source so CocoaPods is happy
  s.source        = { :git => "https://example.com/AppsAirPush.git", :tag => s.version.to_s }

  s.source_files  = "ios/**/*.{h,m,swift}"

  s.dependency "React-Core"
  s.dependency "SSZipArchive"
  s.module_name  = "AppsAirPush"
  s.requires_arc = true
  s.swift_version = "5.0"
end
