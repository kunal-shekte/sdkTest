import RNFS from "react-native-fs";

const versionNameFile = `${RNFS.DocumentDirectoryPath}/version_name.txt`;
const appIdFile = `${RNFS.DocumentDirectoryPath}/app_id.txt`;

export async function readCurrentVersionName() {
  try {
    const content = await RNFS.readFile(versionNameFile, "utf8");
    return content.trim();
  } catch {
    return "NO_ID";
  }
}

export async function saveVersionName(id) {
  return RNFS.writeFile(versionNameFile, id, "utf8");
}

export async function saveAppId(appId) {
  return RNFS.writeFile(appIdFile, appId, "utf8");
}

const blacklistedVersionsFile = `${RNFS.DocumentDirectoryPath}/blacklisted_versions.txt`;

export async function readBlacklistedVersions() {
  try {
    const content = await RNFS.readFile(blacklistedVersionsFile, "utf8");
    if (!content) return [];
    
    return content.split(',').map(v => v.trim()).filter(v => v.length > 0);
  } catch {
    return [];
  }
}
