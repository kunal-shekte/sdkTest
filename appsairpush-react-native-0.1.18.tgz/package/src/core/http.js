import { config } from "./config";
import { log } from "./logger";
import { getNativeAppVersion } from "./nativeModules";
import { readCurrentVersionName } from "./version";

export async function checkForUpdateRequest(blacklistedVersions = []) {
  const current = await readCurrentVersionName();
  const nativeVersion = await getNativeAppVersion();

  log(`Native app version: ${nativeVersion}`);
  let url =
    `https://boldly-achlamydeous-sharonda.ngrok-free.dev/api/v1/bundle/latest` +
    `?platform=${config.platform}` +
    `&appId=${config.appId}` +
    `&nativeVersion=${nativeVersion}`;

  if (blacklistedVersions && blacklistedVersions.length > 0) {
    url += `&blacklisted_versions=${encodeURIComponent(blacklistedVersions.join(','))}`;
  }

  log(`Checking update: ${url}`);
  log(`Current bundle: ${current}`);

  const res = await fetch(url);
  const body = await res.json();

  if (!body?.data) return { hasUpdate: false };

  const latestVersionName = body.data.version_name;

  return {
    hasUpdate: latestVersionName !== current,
    version_name: latestVersionName,
    url: body.data.url,
    version: nativeVersion,
  };
}
