import RNFS from "react-native-fs";
import { Platform } from "react-native";
import { log } from "./logger";
import RNRestart from "react-native-restart-newarch";

let alreadyRestarted = false;

export async function handleFirstLaunchFlag(config) {
  // installer.js writes ota_installed.txt to basePath:
  //   iOS     → RNFS.CachesDirectoryPath
  //   Android → RNFS.DocumentDirectoryPath
  // We must read from the same location.
  const flagDir =
    Platform.OS === "ios"
      ? RNFS.CachesDirectoryPath
      : RNFS.DocumentDirectoryPath;
  const flagFile = `${flagDir}/ota_installed.txt`;

  try {
    const exists = await RNFS.exists(flagFile);

    if (exists) {
      log("First launch after OTA — skipping update check");
      config.skipCheck = true;
      await RNFS.unlink(flagFile).catch(() => {});
    }
  } catch {}
}

// export function restartApp() {
//   if (alreadyRestarted) return;
//   alreadyRestarted = true;

//   log("Restarting app...");
//   DevSettings.reload();
// }

export function restartApp() {
  if (alreadyRestarted) return;
  alreadyRestarted = true;

  log("Restarting app...");
  RNRestart.Restart();
}
