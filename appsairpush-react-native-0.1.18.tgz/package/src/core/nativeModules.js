import { NativeModules, Platform } from "react-native";

const { AppsAirPush } = NativeModules;

export async function getNativeAppVersion() {
  if (!AppsAirPush?.getNativeAppVersion) return null;
  return AppsAirPush.getNativeAppVersion();
}
