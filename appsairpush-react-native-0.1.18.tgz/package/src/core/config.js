export const config = {
    appId: null,
    platform: null,
    skipCheck: false,
  };
  
  export function setConfig(userConfig) {
    Object.assign(config, userConfig);
  }
  