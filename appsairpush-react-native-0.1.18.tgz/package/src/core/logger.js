export function log(msg) {
    console.log("[appsairpush]", msg);
  }
  