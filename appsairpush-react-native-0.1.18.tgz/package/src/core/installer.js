import RNFS from "react-native-fs";
import { NativeModules, Platform } from "react-native";
const { AppsAirPushUnzip, AppsAirPush } = NativeModules;
import { saveVersionName } from "./version";
import { log } from "./logger";
import { restartApp } from "./restart";
import { config } from "./config";

export async function installUpdate({ version_name, url, platform, version }, onDownload) {
  const basePath =
    Platform.OS === "ios"
      ? RNFS.CachesDirectoryPath
      : RNFS.DocumentDirectoryPath;

  const tmp = `${basePath}/ota_tmp.zip`;
  const otaDir = `${basePath}/ota`;
  const flagFile = `${basePath}/ota_installed.txt`;

  try {
    log("Downloading OTA zip...");

    const downloadOpts = { fromUrl: url, toFile: tmp };
    if (typeof onDownload === "function") {
      downloadOpts.progress = (res) => {
        onDownload({
          bytesWritten: res.bytesWritten,
          contentLength: res.contentLength,
          progress: res.contentLength > 0
            ? Math.round((res.bytesWritten / res.contentLength) * 100)
            : 0,
        });
      };
      downloadOpts.progressDivider = 1;
    }
    const dl = await RNFS.downloadFile(downloadOpts).promise;
    if (dl.statusCode !== 200) throw new Error("Download failed");

    log("Extracting OTA zip...");
    await RNFS.unlink(otaDir).catch(() => {});
    await (AppsAirPushUnzip?.unzip ?? AppsAirPush?.unzip)(tmp, otaDir);

    const bundlePath = `${otaDir}/main.jsbundle`;
    const exists = await RNFS.exists(bundlePath);
    if (!exists) throw new Error("main.jsbundle missing");

    await saveVersionName(version_name);
    await RNFS.writeFile(flagFile, "1", "utf8");

    const statUrl =
      `https://boldly-achlamydeous-sharonda.ngrok-free.dev/api/v1/bundle/updateBundleDownloadStat?platform=${config.platform}` +
      `&appId=${config.appId}&versionName=${version_name}&nativeVersion=${version}`;

    await fetch(statUrl);

    log("OTA installed");
    restartApp();

    return { success: true };
  } catch (e) {
    log("Install error: " + e.message);
    return { success: false, error: e.message };
  }
}
