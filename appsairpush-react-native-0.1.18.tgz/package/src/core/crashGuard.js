import { NativeModules } from "react-native";
import { log } from "./logger";

const { AppsAirPush } = NativeModules;

/**
 * Tells the native layer that JS booted successfully.
 * Resets the crash counter to 0 so the boot guard won't
 * wipe the OTA bundle on next launch.
 */
export async function crashCounterReset() {
  try {
    if (!AppsAirPush?.crashCounterReset) {
      log("crashCounterReset not available on native module (old native build?)");
      return;
    }
    await AppsAirPush.crashCounterReset();
    log("Launch marked as successful — crash counter reset");
  } catch (e) {
    log("Failed to mark launch as successful: " + e.message);
  }
}
