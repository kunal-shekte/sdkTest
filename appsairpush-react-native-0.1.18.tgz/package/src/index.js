import { Platform } from "react-native";
import { setConfig, config } from "./core/config";
import { handleFirstLaunchFlag } from "./core/restart";
import { checkForUpdateRequest } from "./core/http";
import { installUpdate } from "./core/installer";
import { crashCounterReset } from "./core/crashGuard";
import { saveAppId, readBlacklistedVersions } from "./core/version";
import { log } from "./core/logger";

async function init(userConfig) {
  setConfig({ ...userConfig, platform: Platform.OS });
  await handleFirstLaunchFlag(config);
  await saveAppId(config.appId);
  setTimeout(async () => {
    await crashCounterReset();
  }, 500);
  log("SDK initialized");
}

async function checkForUpdate() {
  try{
    if (config?.skipCheck) return { hasUpdate: false };
    const blacklistedVersions = await readBlacklistedVersions();
    return checkForUpdateRequest(blacklistedVersions);
  }catch(error){
    log("Check for update error: " + error.message);
    return { hasUpdate: false };
  }
}

async function downloadAndInstall(update, onDownload) {
  return installUpdate(update, onDownload);
}

async function sync(userConfig, onDownload) {
  try {
    await init(userConfig);
    const update = await checkForUpdate();
    if (!update?.hasUpdate) {
      log("No OTA update available.");
      return { updated: false };
    }
    log(`Update available (version_name ${update.version_name}). Installing...`);
    const result = await downloadAndInstall(update, onDownload);
    if (result.success) {
      log("OTA update applied. Restarting...");
      return { updated: true };
    }
    log("Install failed: " + result.error);
    return { updated: false, error: result.error };
  } catch (err) {
    log("Sync error: " + err.message);
    return { updated: false, error: err.message };
  }
}


export default { init, checkForUpdate, downloadAndInstall, sync };
export { init, checkForUpdate, downloadAndInstall, sync };
