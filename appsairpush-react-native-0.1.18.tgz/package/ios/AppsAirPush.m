#import "AppsAirPush.h"
#import <sys/utsname.h>

@implementation AppsAirPush

RCT_EXPORT_MODULE();

static NSInteger const kCrashThreshold = 2;
static NSString *const kCrashCounterKey = @"appsairpush_crash_counter";
static NSString *const kBaseURL = @"https://boldly-achlamydeous-sharonda.ngrok-free.dev";

+ (void)reportCrashToServer:(NSString *)docDir crashCount:(NSInteger)crashCount timeSinceLastLaunchMs:(long long)timeSinceLastLaunchMs
{
  @try {
    NSString *versionFile = [docDir stringByAppendingPathComponent:@"version_name.txt"];
    NSString *appIdFile = [docDir stringByAppendingPathComponent:@"app_id.txt"];

    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:versionFile] || ![fm fileExistsAtPath:appIdFile]) return;

    NSString *versionName = [[NSString stringWithContentsOfFile:versionFile
                                                      encoding:NSUTF8StringEncoding
                                                         error:nil] stringByTrimmingCharactersInSet:
                              [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *appId = [[NSString stringWithContentsOfFile:appIdFile
                                                encoding:NSUTF8StringEncoding
                                                   error:nil] stringByTrimmingCharactersInSet:
                        [NSCharacterSet whitespaceAndNewlineCharacterSet]];

    if (!versionName.length || !appId.length) return;

    NSString *nativeVersion = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
    if (!nativeVersion) nativeVersion = @"0.0.0";

    // Determine crash reason based on timing
    NSString *reason = (timeSinceLastLaunchMs >= 0 && timeSinceLastLaunchMs <= 10000) ? @"restart_too_fast" : @"js_boot_failure";

    // Check if app is running in debug mode
#ifdef DEBUG
    NSString *isDebug = @"true";
#else
    NSString *isDebug = @"false";
#endif

    // Get device model
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *deviceModel = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    NSString *encodedDeviceModel = [deviceModel stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];

    // Get OS version
    NSString *osVersion = [NSString stringWithFormat:@"iOS %@", [[UIDevice currentDevice] systemVersion]];
    NSString *encodedOsVersion = [osVersion stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];

    NSString *urlString = [NSString stringWithFormat:
      @"%@/api/v1/bundle/reportCrash?platform=ios&appId=%@&versionName=%@&nativeVersion=%@&reason=%@&crashCount=%ld&timeSinceLastLaunchMs=%lld&isDebug=%@&deviceModel=%@&osVersion=%@",
      kBaseURL, appId, versionName, nativeVersion, reason, (long)crashCount, timeSinceLastLaunchMs, isDebug, encodedDeviceModel, encodedOsVersion];

    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url
                                             cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
                                         timeoutInterval:5.0];

    // Fire and forget — don't block app startup
    [[NSURLSession.sharedSession dataTaskWithRequest:request] resume];
  }
  @catch (NSException *exception) {
    NSLog(@"[AppsAirPush] reportCrashToServer error: %@", exception);
  }
}

+ (NSURL *)bundleURL
{
  @try {
  NSFileManager *fm = [NSFileManager defaultManager];
  NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];

  NSArray *paths = NSSearchPathForDirectoriesInDomains(
      NSCachesDirectory,
      NSUserDomainMask,
      YES
  );

  NSString *docsDir = [paths firstObject];
  NSString *otaDir = [docsDir stringByAppendingPathComponent:@"ota"];
  NSString *otaBundle = [otaDir stringByAppendingPathComponent:@"main.jsbundle"];

  // Also locate version_name.txt in DocumentDirectory (where the JS layer writes it)
  NSArray *docPaths = NSSearchPathForDirectoriesInDomains(
      NSDocumentDirectory,
      NSUserDomainMask,
      YES
  );
  NSString *docDir = [docPaths firstObject];
  NSString *versionFile = [docDir stringByAppendingPathComponent:@"version_name.txt"];

  // Binary version changed (marketing version) — wipe OTA, reset counter
  NSString *currentBinaryKey = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"] ?: @"0";
  NSString *lastBinaryKey = [defaults stringForKey:@"binary_version_key"];

  if (![lastBinaryKey isEqualToString:currentBinaryKey]) {
    if ([fm fileExistsAtPath:otaDir]) {
      [fm removeItemAtPath:otaDir error:nil];
    }
    
    if ([fm fileExistsAtPath:versionFile]) {
      [fm removeItemAtPath:versionFile error:nil];
    }
    
    NSString *blacklistFile = [docDir stringByAppendingPathComponent:@"blacklisted_versions.txt"];
    if ([fm fileExistsAtPath:blacklistFile]) {
      [fm removeItemAtPath:blacklistFile error:nil];
    }

    [defaults setObject:currentBinaryKey forKey:@"binary_version_key"];
    [defaults setInteger:0 forKey:kCrashCounterKey];
    [defaults synchronize];

    return [[NSBundle mainBundle] URLForResource:@"main" withExtension:@"jsbundle"];
  }

  // --- Crash-safe boot guard ---
  // Save launch timestamp for crash diagnostics
  static NSString *const kLastLaunchTsKey = @"appsairpush_last_launch_ts";
  double now = [[NSDate date] timeIntervalSince1970] * 1000.0;
  double lastLaunchTs = [defaults doubleForKey:kLastLaunchTsKey];
  long long timeSinceLastLaunchMs = (lastLaunchTs > 0) ? (long long)(now - lastLaunchTs) : -1;
  [defaults setDouble:now forKey:kLastLaunchTsKey];

  // Increment crash counter BEFORE JS loads.
  // If JS boots successfully, init() will call crashCounterReset to reset it.
  NSInteger crashCount = [defaults integerForKey:kCrashCounterKey] + 1;
  [defaults setInteger:crashCount forKey:kCrashCounterKey];
  [defaults synchronize];

  if (crashCount >= kCrashThreshold && [fm fileExistsAtPath:otaDir]) {
    // Report crash to server with diagnostic info
    [self reportCrashToServer:docDir crashCount:crashCount timeSinceLastLaunchMs:timeSinceLastLaunchMs];
    
    if ([fm fileExistsAtPath:versionFile]) {
      @try {
        NSString *crashingVersion = [[NSString stringWithContentsOfFile:versionFile
                                                          encoding:NSUTF8StringEncoding
                                                             error:nil] stringByTrimmingCharactersInSet:
                                  [NSCharacterSet whitespaceAndNewlineCharacterSet]];
        
        if (crashingVersion.length > 0) {
            NSString *blacklistFile = [docDir stringByAppendingPathComponent:@"blacklisted_versions.txt"];
            NSString *appendString = [NSString stringWithFormat:@"%@,", crashingVersion];
            
            if (![fm fileExistsAtPath:blacklistFile]) {
                [appendString writeToFile:blacklistFile atomically:YES encoding:NSUTF8StringEncoding error:nil];
            } else {
                NSFileHandle *fileHandle = [NSFileHandle fileHandleForWritingAtPath:blacklistFile];
                [fileHandle seekToEndOfFile];
                [fileHandle writeData:[appendString dataUsingEncoding:NSUTF8StringEncoding]];
                [fileHandle closeFile];
            }
        }
      } @catch (NSException *e) {}

      [fm removeItemAtPath:versionFile error:nil];
    }

    // Wipe the OTA-install flag (CachesDirectory on iOS) so the JS layer does NOT
    // set skipCheck=true on this recovery launch — we want checkForUpdate()
    // to fire immediately and re-fetch the latest non-blacklisted bundle.
    // installer.js writes ota_installed.txt to RNFS.CachesDirectoryPath on iOS
    // which maps to NSCachesDirectory (= docsDir here).
    NSString *flagFilePath = [docsDir stringByAppendingPathComponent:@"ota_installed.txt"];
    if ([fm fileExistsAtPath:flagFilePath]) {
      [fm removeItemAtPath:flagFilePath error:nil];
    }

    [fm removeItemAtPath:otaDir error:nil];
    [defaults setInteger:0 forKey:kCrashCounterKey];
    [defaults synchronize];
    return [[NSBundle mainBundle] URLForResource:@"main" withExtension:@"jsbundle"];
  }

  if ([fm fileExistsAtPath:otaBundle]) {
    return [NSURL fileURLWithPath:otaBundle];
  }

  // No OTA on disk — reset counter, nothing to guard against
  [defaults setInteger:0 forKey:kCrashCounterKey];
  [defaults synchronize];

  NSLog(@"[AppsAirPush] Loading embedded main.jsbundle");
  return [[NSBundle mainBundle] URLForResource:@"main" withExtension:@"jsbundle"];
  }
  @catch (NSException *exception) {
    NSLog(@"[AppsAirPush] Error in bundleURL: %@", exception);
    return [[NSBundle mainBundle] URLForResource:@"main" withExtension:@"jsbundle"];
  }
}

RCT_EXPORT_METHOD(crashCounterReset:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
  @try {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setInteger:0 forKey:kCrashCounterKey];
    [defaults synchronize];
    resolve(@(YES));
  }
  @catch (NSException *exception) {
    reject(@"CRASH_GUARD_ERROR", @"Failed to reset crash counter", nil);
  }
}

RCT_EXPORT_METHOD(getNativeAppVersion:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject)
{
  NSString *version = [[NSBundle mainBundle]
                        objectForInfoDictionaryKey:@"CFBundleShortVersionString"];

  if (version != nil) {
    resolve(version);
  } else {
    reject(@"VERSION_ERROR", @"Unable to read app version", nil);
  }
}

@end