#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>

@interface AppsAirPush : NSObject <RCTBridgeModule>

+ (NSURL *)bundleURL;

@end
