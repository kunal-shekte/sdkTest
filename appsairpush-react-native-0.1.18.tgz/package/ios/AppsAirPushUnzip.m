#import "AppsAirPushUnzip.h"
#import <SSZipArchive/SSZipArchive.h>

@implementation AppsAirPushUnzip

RCT_EXPORT_MODULE();

RCT_EXPORT_METHOD(unzip:(NSString *)zipPath
                  dest:(NSString *)destPath
                  resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject)
{
  BOOL success = [SSZipArchive unzipFileAtPath:zipPath toDestination:destPath];

  if (success) {
    resolve(@(YES));
  } else {
    reject(@"unzip_error", @"Failed to unzip archive", nil);
  }
}

@end
