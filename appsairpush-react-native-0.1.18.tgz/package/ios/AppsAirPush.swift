import Foundation

@objc(AppsAirPushSwift)
public class AppsAirPushSwift: NSObject {
  
  @objc public static func bundleURL() -> URL? {
      return AppsAirPush.bundleURL()
  }
}
