# appsairpush-react-native

A lightweight React Native SDK for integrating AppsAirPush OTA updates into your mobile applications.

---

## 🚀 About

appsairpush-react-native enables your app to:

- Check for new OTA updates
- Download incremental JS bundles
- Apply updates instantly on next launch
- Work seamlessly with the AppsAirPush CLI

---

## 📚 Documentation

Full documentation is available here:

👉 [https://boldly-achlamydeous-sharonda.ngrok-free.dev/docs](https://boldly-achlamydeous-sharonda.ngrok-free.dev/docs)

This includes:

- Installation guide
- Setup instructions
- API reference
- Update checking flow
- Troubleshooting

All future updates, examples, and detailed steps will be maintained on the documentation website.

---

## 🛠 Installation

npm install appsairpush-react-native


---

## 📄 License

Commercial license.  
Enterprise support available.

---

## 🧑‍💻 Author

Maintained by AppsAirPush Team  
Website: [https://boldly-achlamydeous-sharonda.ngrok-free.dev](https://boldly-achlamydeous-sharonda.ngrok-free.dev)

---

## 📬 Support

Email: [support@appsairpush.com](mailto:support@appsairpush.com)